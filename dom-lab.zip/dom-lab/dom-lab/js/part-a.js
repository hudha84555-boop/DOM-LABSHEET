 console.log("DOM lab ready");

 // Task A2: selecting
const title = document.getElementById("title");
const tagline = document.querySelector(".tagline");
const menuList = document.getElementById("menu-list");
const items = document.querySelectorAll(".item");
const message = document.getElementById("message");
const nameBox = document.getElementById("name-input");

// Task A3: change the text
title.textContent = "Lagoon Café · Open now";
tagline.textContent = "Fresh food by the lagoon since 2010";

items.forEach((item, index) => {
  item.textContent = `${index + 1}. ${item.textContent}`;
});

message.innerHTML = "<strong>Welcome!</strong> Today's special is crab curry.";

console.log(nameBox.value);

//task A4

document.querySelector(".special").classList.add("highlight");
document.querySelector(".nav-link").classList.add("active");
nameBox.setAttribute("placeholder", "Type your first name");
document.getElementById("hours").style.color = "crimson";
items.forEach((item) => {
  console.log(item.textContent, item.classList.contains("special"));
});

// Task A5: build the menu

// A5.1: add Egg hoppers at the end of the menu
const li = document.createElement("li");   // 1. create
li.textContent = "Egg hoppers";            // 2. fill
li.classList.add("item");
menuList.append(li);                       // 3. attach at the end

// A5.2: Drinks section built from an array
const drinks = ["Faluda", "King coconut", "Plain tea"];

const drinksHeading = document.createElement("h2");
drinksHeading.textContent = "Drinks";

const drinksList = document.createElement("ul");
drinks.forEach((drink) => {
  const drinkItem = document.createElement("li");
  drinkItem.textContent = drink;
  drinksList.append(drinkItem);
});

// put both just before the "Opening hours" heading
document.getElementById("hours").before(drinksHeading, drinksList);

// A5.3: Kottu has sold out, so remove it
const kottu = [...document.querySelectorAll("#menu-list li")]
  .find((item) => item.textContent.includes("Kottu"));
kottu.remove();

// A5.4 (challenge): opening hours table from data
const hours = [
  { day: "Monday to Friday", time: "8 am to 9 pm" },
  { day: "Saturday", time: "8 am to 10 pm" },
  { day: "Sunday", time: "Closed" }
];

const table = document.createElement("table");
hours.forEach((entry) => {
  const tr = document.createElement("tr");

  const dayCell = document.createElement("td");
  dayCell.textContent = entry.day;

  const timeCell = document.createElement("td");
  timeCell.textContent = entry.time;

  tr.append(dayCell, timeCell);
  table.append(tr);
});

// place it after the Opening hours paragraph
document.querySelector(".hours").after(table);
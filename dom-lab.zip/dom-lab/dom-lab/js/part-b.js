//task B1
const greetBtn = document.getElementById("greet-btn");
greetBtn.addEventListener("click", () => {
  message.textContent = `Hello! The time is ${new Date().toLocaleTimeString()}`;
});

const themeBtn = document.getElementById("theme-btn");
themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  themeBtn.textContent = document.body.classList.contains("dark")
    ? "Light mode"
    : "Dark mode";
});

const title = document.getElementById("title");
let titleClicks = 0;
title.addEventListener("click", () => {
  titleClicks++;
  message.textContent = `Title clicked ${titleClicks} times`;
});

//task B2
const nameBox = document.getElementById("name-input");
const preview = document.getElementById("preview");
const counter = document.getElementById("counter");

nameBox.addEventListener("input", () => {
  const text = nameBox.value;
  preview.textContent = text.trim() === "" ? "" : `Hello, ${text}!`;
  counter.textContent = `${text.length} / 20`;
  counter.classList.toggle("error", text.length > 20);
});

const menuItems = document.querySelectorAll(".item");
menuItems.forEach((item) => {
  item.addEventListener("mouseover", () => item.classList.add("highlight"));
  item.addEventListener("mouseout", () => item.classList.remove("highlight"));
});

//task B3
nameBox.addEventListener("keydown", (e) => {
  console.log(e.key);
  if (e.key === "Enter") {
    message.textContent = `Saved name: ${nameBox.value}`;
  }
});

const navLinks = document.querySelectorAll(".nav-link");
navLinks.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    navLinks.forEach((l) => l.classList.remove("active"));
    e.target.classList.add("active");
    message.textContent = `You chose ${e.target.textContent}`;
  });
});

//task B4
const menuList = document.getElementById("menu-list");
menuList.addEventListener("click", (e) => {
  console.log(e.target, e.currentTarget);
  const item = e.target.closest("li");
  if (!item) return;
  item.classList.toggle("done");
});

// Task B4.4 (challenge): double-click to delete
menuList.addEventListener("dblclick", (e) => {
  const item = e.target.closest("li");
  if (item) item.remove();
});

const li = document.createElement("li");
li.textContent = "Egg hoppers";
document.getElementById("menu-list").append(li);
